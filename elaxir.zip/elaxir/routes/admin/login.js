const express = require('express');
var router = express.Router();
var bcrypt = require('bcryptjs');
var mysql = require('mysql');
var con = require('../../configs/DBConnection');
router.get("/",function(req,res) {
  res.render("admin/login.ejs");
});
router.post("/",function(req,res) {
  // console.log(req.body);
  if(req.body.username == process.env.adminname && req.body.password == process.env.adminpassword){
    res.render("admin/panel.ejs");
  }else{
    var query = "SELECT * FROM admin WHERE username = ?";
    con.query(query,[req.body.username],function(err,data) {
      if(err) throw err;
      console.log(data);
      if(data.length == 0){
        res.render("admin/login.ejs");
      }else{
        bcrypt.compare(req.body.password,data[0].password,function(err,respond) {
           if(respond){
             res.render("admin/secpanel.ejs");
           }
           else{
             res.render("admin/login.ejs");
           }
        });
      }
    });
  }

});
router.post("/admincreate",function(req,res) {
  var usrname = req.body.username;
  var password = req.body.password;
  let salt =  bcrypt.genSaltSync(10);
  var newpassword =  bcrypt.hashSync(password, salt);
  var insertquery = "INSERT INTO admin (username, password) VALUES (?,?)";
  var query = mysql.format(insertquery,[usrname,newpassword]);

  con.query(query, function (err, result) {
     if (err) throw err;
     // console.log("1 record inserted");
      res.render("admin/panel.ejs");
     // res.render('admin/blogadmin.ejs');

     });
});

module.exports = router;

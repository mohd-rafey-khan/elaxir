const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');


router.get("/addcategory",function (req,res) {
  var query = "SELECT * FROM category";
  con.query(query,function(err,respond) {
    res.render("admin/addcategory.ejs",{data:respond});
  });
});
router.post("/addcategory",function(req,res) {
  var name = req.body.category;
  con.query("INSERT INTO category (name) VALUES (?)",[name], function(err) {
    if(err) throw err;
    res.redirect("/admin/addcategory");
  });
});
router.post("/catdel",function(req,res) {
  var deleteid = req.body.id;
  var query = "DELETE FROM category WHERE id = ?";
  con.query(query,[deleteid], function (err, result) {
   if (err) throw err;
   res.redirect("/admin/addcategory");
 });
});

module.exports = router;

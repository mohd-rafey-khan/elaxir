const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');
var path = require("path");
//**************************************************************************
//**************************************************************************
router.get("/addproduct",function(req,res) {
  if(req.session.admin != undefined && Object.keys(req.session.admin).length !=0) {
    var query = "SELECT * FROM category";
    con.query(query,function(err,respond) {
      var query = "SELECT * FROM product WHERE name = ?";
      con.query(query,['NA'],function(err,data) {
        if(err) throw err;
        res.render("admin/addproduct.ejs",{uploadstatus:"",data:respond,all:data});
      });
    });
  } else {
    res.redirect("/admin/adminlogin");
  }
});
router.post("/addproduct",function(req,res) {
  // console.log(req.files.prodimg[0]);
  var category = req.body.category;
  var len = req.files.prodimg.length;
  var datetime = new Date().getDate();
  for(i = 0;i<len;i++){
    var filename = req.files.prodimg[i].name;
    let sampleFile = req.files.prodimg[i];
    var dirpath = "../../public/upload/product/"+filename;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {
          if (err)
          return res.status(500).send(err);
      });
      con.query("INSERT INTO product (image,category,date) VALUES (?,?,?)",[filename,category,datetime], function(err) {
        if(err) throw err;
        // res.redirect("/admin/addproduct");
      });

  }

   res.redirect("/admin/addproduct");
});
router.post("/addname",function(req,res) {
  var id = req.body.id;
  var name = req.body.name;
  var query = "UPDATE product SET name = ? WHERE id = ?";
  con.query(query,[name,id],function(err,respond) {
    if(err) throw err;
    res.redirect("/admin/addproduct");
  });
});
router.post("/proddel",function(req,res) {
  var id  = req.body.id;
  var query = "DELETE FROM product WHERE id = ?";
  con.query(query,[id],function(err,respond) {
    if(err) throw err;
    res.redirect("/admin/addproduct");
  });
});

module.exports = router;

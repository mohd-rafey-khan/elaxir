const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');

router.get("/admindel",function(req,res) {
  var query = "SELECT * FROM admin";
  con.query(query,function(err,respond) {
    if(err) throw err;
    res.render("admin/adminuser.ejs",{data:respond});
  });
});
router.post("/admindel",function(req,res) {
  delid = req.body.id;
  var query = "DELETE FROM admin WHERE id = ?";
  con.query(query,[delid],function(err,respond) {
    if(err) throw err;
    res.redirect("/admin/admindel");
    // console.log(respond);
  })
});

module.exports = router;

const express = require('express');
var router = express.Router();
const con = require("../../configs/DBConnection");
const mysql = require('mysql');
var Cart = require("../../services/cart");
router.get('/add-to-cart/:id', function(req, res, next){
    
    if(req.session.customer != undefined && req.session.customer!=null) {
            var productId = req.params.id;
            var cart = new Cart(req.session.cart ? req.session.cart : {});
            var products = [];
        
            con.query("SELECT * FROM product WHERE id = ?",[productId], function (err, product) {
                if (err) throw err;
            //   products = result;
                if(product.length >0){
                    cart.add(product[0], product[0].id);
                    req.session.cart = cart;
                }
                res.redirect("/shopping-cart");
            });
    } else {
            res.redirect("/login");
    }
  });
  
  router.get('/shopping-cart', function(req, res, next) {
    if(req.session.customer != undefined && req.session.customer!=null) {
        if (!req.session.cart) {
            return res.render('frontend/shoppingCart', {products: null, totalQty:0});
        }
        var cart = new Cart(req.session.cart);
        res.render('frontend/shoppingCart', {products: cart.generateArray(), totalQty: cart.totalQty});
    } else {
        res.redirect("/login");
    }
  });
    
  router.get('/remove/:id', function(req, res, next) {
    if(req.session.customer != undefined && req.session.customer!=null) {
      var productId = req.params.id;
      var cart = new Cart(req.session.cart ? req.session.cart : {});
      cart.removeItem(productId);
      req.session.cart = cart;
      res.redirect('/shopping-cart');
    } else {
        res.redirect("/login");
    }
  });

  router.get("/checkout", function(req, res) {
    if(req.session.customer != undefined && req.session.customer!=null) {
        var productsInCart  = Object.keys(req.session.cart.items);
        var productIds = "";
        productsInCart.forEach(element => {
            productIds = productIds +" "+ element;
        });
        productIds =  productIds.trim();
        
        con.query("INSERT INTO orderhistory (user_name, user_contact, products) VALUES (?,?, ?)",[req.session.customer.name, req.session.customer.number, productIds], function(err) {
            if(err) throw err;
            req.session.cart = null;
            res.redirect("/");
        });
      } else {
          res.redirect("/login");
      }
  });

module.exports = router;
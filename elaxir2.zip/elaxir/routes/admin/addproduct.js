const express = require('express');
var router = express.Router();

//**************************************************************************
//**************************************************************************
router.get("/",function(req,res) {
  res.render("admin/addproduct.ejs");
});
router.post("/",function(req,res) {
  console.log(req.body);
  res.send();
});


module.exports = router;

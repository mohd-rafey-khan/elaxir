const express = require('express');
var router = express.Router();

router.get("/",function(req,res) {
  res.render("admin/login.ejs");
});
router.post("/",function(req,res) {
  // console.log(req.body);
  if(req.body.name == 'Rafey'){
    res.render("admin/panel.ejs");
  }else{
    res.render("admin/login.ejs");
  }
});

module.exports = router;
